var activity = [
'<table border="2">
<tr>
<td><b>Representing a Letter:</b>
<p>In the last video, you learned how black and white images can be 
represented using bits and numbers. What letter of the alphabet would 
be represented by the following set of numbers?
<p>
<img src="assets/img/imagebynumbers.png" height=165 width=57></p>
</td>
</tr>
</table>
<br/>'
]